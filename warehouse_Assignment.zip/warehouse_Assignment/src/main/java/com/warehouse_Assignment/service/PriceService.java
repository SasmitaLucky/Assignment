package com.warehouse_Assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.warehouse_Assignment.bean.Price;
import com.warehouse_Assignment.dao.PriceRepository;

@Service
public class PriceService {
	@Autowired
	private PriceRepository priceRepository;

	public List<Price> getAllPrices() {
		return priceRepository.findAll();
	}

	public Price getPriceByArticleId(String id) {
		return priceRepository.findById(id).orElse(null);
	}

	public Price createOrUpdatePrice(Price price) {
		return priceRepository.save(price);
	}

	public void deletePrice(String id) {
		priceRepository.deleteById(id);
	}

}
