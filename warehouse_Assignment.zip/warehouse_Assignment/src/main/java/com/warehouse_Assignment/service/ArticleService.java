package com.warehouse_Assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.warehouse_Assignment.bean.Article;
import com.warehouse_Assignment.dao.ArticleRepository;

@Service
public class ArticleService {
	
	@Autowired
    private ArticleRepository articleRepository;

    public List<Article> getAllArticles() {
        return articleRepository.findAll();
    }

    public Article getArticleById(String id) {
        return articleRepository.findById(id).orElse(null);
    }

    public Article createOrUpdateArticle(Article article) {
        return articleRepository.save(article);
    }

    public void deleteArticle(String id) {
        articleRepository.deleteById(id);
    }

}
