package com.warehouse_Assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WarehouseAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(WarehouseAssignmentApplication.class, args);
	}

}
