package com.warehouse_Assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.warehouse_Assignment.bean.Price;
import com.warehouse_Assignment.service.PriceService;

@RestController
@RequestMapping("/prices")
public class PriceController {
	
	@Autowired
    private PriceService priceService;

    @GetMapping
    public List<Price> getAllPrices() {
        return priceService.getAllPrices();
    }

    @GetMapping("/{id}")
    public Price getPriceByArticleId(@PathVariable String id) {
        return priceService.getPriceByArticleId(id);
    }

    @PostMapping
    public Price createPrice(@RequestBody Price price) {
        return priceService.createOrUpdatePrice(price);
    }

    @PutMapping("/{id}")
    public Price updatePrice(@PathVariable String id, @RequestBody Price price) {
        price.setArtId(id);
        return priceService.createOrUpdatePrice(price);
    }

    @DeleteMapping("/{id}")
    public void deletePrice(@PathVariable String id) {
        priceService.deletePrice(id);
    }

}
