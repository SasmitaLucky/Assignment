package com.warehouse_Assignment.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Price {

	@Id
	private String artId;
	private double price;
	
	public String getArtId() {
		return artId;
	}
	public void setArtId(String artId) {
		this.artId = artId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
}
