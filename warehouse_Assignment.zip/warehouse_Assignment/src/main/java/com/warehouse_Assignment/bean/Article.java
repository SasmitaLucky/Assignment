package com.warehouse_Assignment.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Article {
	
	@Id
    private String id;
    private String artName;
    private int stock;
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getArtName() {
		return artName;
	}
	public void setArtName(String artName) {
		this.artName = artName;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
    
    

}
