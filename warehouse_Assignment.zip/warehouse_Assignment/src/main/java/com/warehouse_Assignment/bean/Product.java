package com.warehouse_Assignment.bean;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Product {

	@Id
	private String prodId;
	private String productName;
	@OneToMany(cascade = CascadeType.ALL)
	private List<ProductArticle> articles;
	private double price;
	
	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public List<ProductArticle> getArticles() {
		return articles;
	}
	public void setArticles(List<ProductArticle> articles) {
		this.articles = articles;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}
